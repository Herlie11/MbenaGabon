from flask import Flask, request, jsonify, send_from_directory
import random

app = Flask(__name__, static_folder='.', template_folder='.')

# Dictionnaires de traductions
translations = {
    "fang": {"bonjour": "mbolo", "salut": "mbolo", "merci": "akiba"},
    "punu": {"bonjour": "maramboura", "salut": "maramboura", "merci": "dibotsi"},
    "myene": {"bonjour": "mbolo", "salut": "mbolo", "merci": "akiba"},
}

@app.route('/')
def serve_html():
    return send_from_directory('.', 'index.html')

@app.route('/translate', methods=['POST'])
def translate():
    data = request.get_json()
    language = data.get('language')
    phrase = data.get('phrase', '').lower()
    translation = translations.get(language, {}).get(phrase, "Traduction non trouvée")
    return jsonify({"translation": translation})

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    message = data.get('message', '').lower()
    greetings = ["bonjour", "salut", "hey", "bonsoir", "yo"]
    responses = [
        "Bonjour, comment vas-tu ? Que puis-je traduire pour toi ?",
        "Salut, comment vas-tu ? Veux-tu traduire quelque chose ?",
        "Bonsoir, comment vas-tu ? Que puis-je faire pour toi ?",
        "Hey, comment vas-tu ? Comment puis-je t’aider ?",
        "Yo, comment vas-tu ? Que veux-tu traduire ou discuter ?"
    ]
    if message in greetings:
        response = random.choice(responses)
    else:
        response = "Je suis là pour t’aider. Que veux-tu traduire ou discuter ?"
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)